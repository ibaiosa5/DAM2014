generator-webapp-rjs-testing
============================

Testing Web app generator with RequireJS

FizzBuzz Kata
