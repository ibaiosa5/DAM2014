define('app', ['jquery', 'FizzBuzz'], function($, FizzBuzz) {
    console.log('App started');
});