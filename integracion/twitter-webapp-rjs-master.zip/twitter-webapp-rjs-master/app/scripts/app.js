define([], function() {
  console.log('App started');
});