<?php
    $consumer_key = ""; 
    $consumer_secret = "";
    $user_token = "";
    $user_secret = "";
?>